<?php
include "manage_header.php";
?>
<input name="gid" value="<?=$gid?>" type="hidden">

<br><br>
<h2 id="tables-contextual-classes">|DB서버구성도</h2>

<?
$mainDB = DBGroup::create("main");

echo "main server<br>";

for($i=0;$i<$mainDB->getMasterCount();$i++){
	$master = $mainDB->getMaster($i+1);
	echo "MASTER".($i+1)." - ".$master->m_name."<br>";
	for($j=0;$j<$master->getSlaveCount();$i++){
		$slave = $master->getSlave($j+1);
		echo "SLAVE".($j+1)." - ".$slave->m_name."<br>";
	}
}

?>



<?php
include "manage_footer.php";
?>