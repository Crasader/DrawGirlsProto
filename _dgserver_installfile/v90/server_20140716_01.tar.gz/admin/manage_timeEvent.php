<?php
include "manage_header.php";
?>

<br><br>
<h2 id="tables-contextual-classes">|타임 이벤트</h2>
<table class="LQDataTable" dbSource="dataManager2.php"  dbClass="TimeEvent" dbWhere='' autoSetting="true" name="datatable" editRowOnly="true" editType="form" border=1>
	<thead>
	</thead>
	<tbody datazone>

	</tbody>
</table>

<?php
include "manage_footer.php";
?>