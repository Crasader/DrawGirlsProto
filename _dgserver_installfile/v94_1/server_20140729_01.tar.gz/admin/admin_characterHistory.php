<?php
include "header.php";

?>

<table class="LQDataTable" dbSource="dataManager2.php"  dbClass="CharacterHistory" autoSetting="true" dbWhere='{}' name="datatable" border=1>
	<thead>
	</thead>
	<tbody datazone>

	</tbody>
</table>

<?php
include "footer.php";
?>