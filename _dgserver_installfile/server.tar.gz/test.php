	<?php

include "lib.php";
include "command/cmd2.php";

	// $command = new commandClass();

	// $ps["memberID"]=12;
	// {
	// 	$actions["action"]="updateGoldHistory";
	// 	$actions["param"]=array("memberID"=>"12","changeCount"=>1000);
	// 	$ps["actions"][]=$actions;
	// }
	// {
	// 	$actions["action"]="addGold";
	// 	$actions["param"]=array("memberID"=>"12","count"=>1000);
	// 	$ps["actions"][]=$actions;
	// }

	// $r=$command->tranjaction($ps);
	// echo json_encode($r,JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK);
	// echo "<br><br>";
	// echo json_encode(LogManager::get()->getLogAndClear(),JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK);
	// echo "<br><br>";
?>