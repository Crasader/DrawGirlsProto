# -*- coding: utf-8 -*-
from Crypto.Cipher import AES
from Crypto import Random
import base64

import urllib
import sys
import threading, time
import resource
from time import sleep
import random
import json
#obj = DES.new("12345678", DES.MODE_ECB)

#encrypted = obj.encrypt("Please  ")
#print base64.b64encode(encrypted)

#ret = base64.b64decode("YVcIYD8l/yg=")
#print "%r" % obj.decrypt(ret)
exeCount = 0
failCount = 0
serverUrl = ""
threads = 0
BS = 16
pad = lambda s: s + (BS - len(s) % BS) * chr(BS - len(s) % BS) 
unpad = lambda s : s[0:-ord(s[-1])]

key = "qrqhyrlgprghedvh"

def encodeCmd(codestr):
  global key
  #iv = Random.new().read(AES.block_size)
  cipher = AES.new(key,AES.MODE_ECB)
  fillCount = 16 - len(codestr) % 16;
  for i in range(0, fillCount):
      codestr = codestr + " ";
  encrypted = cipher.encrypt(codestr)
  paramStr = base64.b64encode(encrypted)
  return paramStr

def decodeCmd(codestr):
  global key
  #iv = Random.new().read(AES.block_size)
  cipher = AES.new(key,AES.MODE_ECB)
  rstring = base64.b64decode(codestr)
  rstring = cipher.decrypt(rstring)
  return rstring

def urlreq(sUrl,jsonstring):

    paramStr = encodeCmd(jsonstring)
    #for temp in range(0, 10) :
    try:
        global exeCount
        global failCount
        d = urllib.urlencode({"gid":"drawgirls_tstore","version":2,"command":paramStr})

        f = urllib.urlopen("http://"+sUrl+"/command.php",d);
        # try:
        #   f = urllib.urlopen("http://"+sUrl+"/command.php",d);
        # except soket.timeout, e:
        #   resultstr = "error";
        #print f.headers
        #print f.code
        #print f.read()
        resultstr = f.read()
        if resultstr[len(resultstr) - 1] != '#':
            failCount += 1
            
        exeCount += 1
        f.close()
        return (resultstr, f.code)
    except IOError, e:
        print e
def stress1(thNo,cycle):
    global exeCount
    global failCount
    global serverUrl
    global threads

    count = 1
    memNo = (thNo)+1000000
    allexec = threads*cycle
    while True:
        if cycle < count:
            break

        senddata1 = {"0":{"a":"getpuzzlelist","p":{}},"memberID": memNo,"dontcheck":True}
        jsonString = json.dumps(senddata1)
        urlreq(serverUrl,jsonString)
        #rstring = decodeCmd(r[0][:-1])
        print "%d / %d ...  %d / %d ... fail : %d" % (count, memNo, exeCount, allexec,failCount)
        count = count + 1
        #result = urlreq(random.choice(jsonString))
def main():
    #maxOpenNumbers = resource.getrlimit(resource.RLIMIT_NOFILE)[0] # 열 수 있는 파일 개수.
    global serverUrl

    print "select Server"
    print "1. 182.162.201.147:10010 (Dev)";
    print "2. 182.162.196.182:10080 (Alpha)";
    print "3. 222.122.203.7:10080 (Real)";
    
    serverUrl = raw_input(">")

    if serverUrl == "1":
      serverUrl = "182.162.201.147:10010"
    elif serverUrl == "2":
      serverUrl = "182.162.196.182:10080"
    elif serverUrl == "2":
      serverUrl = "222.122.203.7:10080"


    print "1. 기본테스트";
    print "2. 가입테스트";
    print "3. 기본테스트";
    print "4. 기본테스트";

    a = input(">");
    if a == 1:
        global exeCount
        global failCount
        global threads
        print "유저수? (thread)"
        threads = input(">")
        print "유저당 몇회 호출? (cycle)"
        cycle = input(">")
        exeCount = 0
        failCount = 0 
        
        print "connect to "+serverUrl
        for temp in range(1,  threads+1):
            th = threading.Thread(target = stress1, args=(temp,cycle,))
            th.start()
        pass
    elif a == 2:
        pass
    elif a == 3:
        pass
    elif a == 4:
        pass
if __name__ == '__main__':
    main()
    sys.exit(0)



